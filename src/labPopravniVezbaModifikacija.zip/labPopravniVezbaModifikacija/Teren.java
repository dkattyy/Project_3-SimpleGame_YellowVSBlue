package labPopravniVezbaModifikacija;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Teren extends Panel{

	private int rows, columns;
	private Polje grid[][];
	private Polje oznaceno=null;
	private ArrayList<Akter> akteri=new ArrayList<>();
	private GlavniAkter igrac=null; 
	
	public Teren(int rows, int columns) {
		this.rows=rows;
		this.columns=columns;
		this.setLayout(new GridLayout(rows, columns, 1,1));
		
		grid=new Polje[rows][columns];
		
		for(int i=0; i<rows;i ++) {
			for(int j=0;j<columns;j++) {
				Pozicija p=new Pozicija(i, j);
				grid[i][j]=new Prolaz(Color.gray, this, p);
				this.add(grid[i][j]);
				
				grid[i][j].addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						oznaciPolje((Polje) e.getSource());
					}
				});
			}
		}
		
		setFocusable(true);
		requestFocusInWindow();
		
		addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int key = e.getKeyCode();
	            switch (key) {
					case KeyEvent.VK_W: {
						pomeriIgracaGore();
						break;
					} 
					case KeyEvent.VK_S:{
						pomeriIgracaDole();
						break;
					}
					case KeyEvent.VK_A:{
						pomeriIgracaLevo();
						break;
					}
					case KeyEvent.VK_D:{
						pomeriIgracaDesno();
						break;
					}
				}
				
				revalidate();
				repaint();
			}
		});
	}
	
	public void pomeriIgracaGore() {
		if(igrac!=null) {
			Pozicija p=igrac.getPozicija();
			int x=p.getVrsta();
			int y=p.getKolona();
			if(grid[x-1][y] instanceof Prolaz && x>0) {
				grid[x-1][y].postaviAktera(igrac);
				grid[x][y].ukloniAktera();
				igrac.poz=new Pozicija(x-1, y);
			}
		}
	}

	public void pomeriIgracaDole() {
		if(igrac!=null) {
			Pozicija p=igrac.getPozicija();
			int x=p.getVrsta();
			int y=p.getKolona();
			if(grid[x+1][y] instanceof Prolaz && x<rows-1 ) {
				grid[x+1][y].postaviAktera(igrac);
				grid[x][y].ukloniAktera();
				igrac.poz=new Pozicija(x+1, y);
			}
		}
	}
	public void pomeriIgracaLevo() {
	    if (igrac != null) {
	        Pozicija p = igrac.getPozicija();
	        int x = p.getVrsta();
	        int y = p.getKolona();
	        if (y > 0 && grid[x][y - 1] instanceof Prolaz) {
	            grid[x][y - 1].postaviAktera(igrac);
	            grid[x][y].ukloniAktera();
	            igrac.poz = new Pozicija(x, y - 1);
	        }
	    }
	}

	public void pomeriIgracaDesno() {
	    if (igrac != null) {
	        Pozicija p = igrac.getPozicija();
	        int x = p.getVrsta();
	        int y = p.getKolona();
	        if (y < columns - 1 && grid[x][y + 1] instanceof Prolaz) {
	            grid[x][y + 1].postaviAktera(igrac);
	            grid[x][y].ukloniAktera();
	            igrac.poz = new Pozicija(x, y + 1);
	        }
	    }
	}

	protected void oznaciPolje(Polje polje) {
		if(oznaceno==null) {
			polje.oznaciPolje(true);
			oznaceno=polje;
			oznaceno.oznaciPolje(true);
		}else {
			for(int i=0; i<rows;i ++) {
				for(int j=0;j<columns;j++) {
					if(oznaceno==grid[i][j]) {
						grid[i][j].oznaciPolje(false);
						break;
					}
				}
			}
			
			for(int i=0; i<rows;i ++) {
				for(int j=0;j<columns;j++) {
					if(polje==grid[i][j]) {
						oznaceno=polje;
						grid[i][j].oznaciPolje(true);
						break;
					}
				}
			}
		}
		
	}
	
	public void generisiSlucajno() {
		removeAll();
		if(igrac!=null) igrac=null;
		
		grid=new Polje[rows][columns];
		for(int i=0; i<rows;i ++) {
			for(int j=0;j<columns;j++) {
				Pozicija p=new Pozicija(i, j);
				double r=Math.random();
				if(r<=0.2) grid[i][j]=new Zid(Color.DARK_GRAY,this, p);
				else grid[i][j]=new Prolaz(Color.gray, this, p);
				this.add(grid[i][j]);
				
				grid[i][j].addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						oznaciPolje((Polje) e.getSource());
					}
				});
				
			}
		}
		
		for(int i=0; i<rows; i++) {
			for(int j=0; j<columns;j++) {
				if(grid[i][j] instanceof Prolaz) {
					if(igrac==null) {
						Pozicija p=grid[i][j].getPoz();
						igrac=new GlavniAkter(this, p);
						grid[i][j].postaviAktera(igrac);
						
					}
					else{//dodavanje novcica na sve ostale prolaze
					Pozicija p =grid[i][j].getPoz();
					Novcic n =new Novcic(this, p);
					grid[i][j].postaviAktera(n);
					}
				}
			}
		}
		revalidate();
		repaint();
	}
	
	public void dodajGlavnogAktera() {
		//dodajemo na oznaceno polje
		if(oznaceno!=null) {
			Pozicija p=oznaceno.getPoz();
			int red=p.getVrsta();
			int kolona=p.getKolona();
			
			if(grid[red][kolona].akterMozeDaStane()) {
				GlavniAkter ga=new GlavniAkter(this, p);
				grid[red][kolona].postaviAktera(ga);
	
				akteri.add(ga);
				revalidate();
				repaint();
			}else return;
		}
	}
	
	public void dodajSporednogAktera() {
		if(oznaceno!=null) {
			Pozicija p=oznaceno.getPoz();
			int x=p.getVrsta();
			int y=p.getKolona();
			
			if(grid[x][y].akterMozeDaStane()) {
				SporedniAkter sa=new SporedniAkter(this, p);
				grid[x][y].postaviAktera(sa);
				
				akteri.add(sa);
				revalidate();
				repaint();
			}
		}
	}
	
	public void dodajZid() {
		if(oznaceno!=null) {
			Pozicija p=oznaceno.getPoz();
			int red=p.getVrsta();
			int kolona=p.getKolona();
			
			remove(grid[red][kolona]);
			
			grid[red][kolona].oznaciPolje(false);
			grid[red][kolona]=new Zid(Color.DARK_GRAY, this, p);
			
			grid[red][kolona].addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					oznaciPolje((Polje) e.getSource());
				}
			});
			
			this.add(grid[red][kolona], red*columns+kolona);

			oznaceno=null;
			
			revalidate();
			repaint();
		}
	}
	
	public void dodajProlaz() {
		if(oznaceno!=null) {
			Pozicija p=oznaceno.getPoz();
			int red=p.getVrsta();
			int kolona=p.getKolona();
			
			this.remove(grid[red][kolona]);
			
			grid[red][kolona].oznaciPolje(false);
			grid[red][kolona]=new Prolaz(Color.gray, this, p);
			
			grid[red][kolona].addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					oznaciPolje((Polje) e.getSource());
				}
			});
			
			this.add(grid[red][kolona], red*columns + kolona);
			
			oznaceno=null;
			revalidate();
			repaint();
			
		}
	}
	public Polje dohvatiSaPozicije(Pozicija p) {
		int row=p.getVrsta();
		int column=p.getKolona();

		return grid[row][column];
	}

}
