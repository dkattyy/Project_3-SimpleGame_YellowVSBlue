package labPopravniVezbaModifikacija;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Igra extends Frame {

	Teren teren;
	Panel desniPanel=new Panel();
	Checkbox zid=new Checkbox("Zid");
	Checkbox prolaz=new Checkbox("Prolaz");
	Checkbox glavniAkter=new Checkbox("GAkter");
	Checkbox sporedniAkter=new Checkbox("SAkter");

	CheckboxGroup grupa=new CheckboxGroup();
	
	Button postavi=new Button("Postavi");
	Button nasumicno=new Button("Nasumicno");

	
	
	public Igra() {
		setBounds(700, 200, 600, 200);
		setResizable(false);
		
		setTitle("Igra");
		
		populateWindow();
		pack();
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
		teren.requestFocusInWindow();
		setVisible(true);
	}
	
	
	private void populateWindow() {
		teren=new Teren(6, 12);
		this.add(teren, BorderLayout.CENTER);
		
		desniPanel.setLayout(new GridLayout(3, 1, 10, 10));
		zid.setCheckboxGroup(grupa);
		prolaz.setCheckboxGroup(grupa);
		glavniAkter.setCheckboxGroup(grupa);
		sporedniAkter.setCheckboxGroup(grupa);

		
		
		Panel radioDugmad=new Panel();
		radioDugmad.add(zid);
		radioDugmad.add(prolaz);
		radioDugmad.add(glavniAkter);
		radioDugmad.add(sporedniAkter);

		
		nasumicno.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				teren.generisiSlucajno();
			}
			
		});
		
		postavi.addActionListener(ae->{
			if(zid.getState()) {
				teren.dodajZid();
				teren.repaint();
			}
			else if(prolaz.getState()) {
				teren.dodajProlaz();
				teren.repaint();
			}
			else if(glavniAkter.getState()) {
				teren.dodajGlavnogAktera();
				teren.repaint();
			}
			else if(sporedniAkter.getState()) {
				teren.dodajSporednogAktera();
				teren.repaint();
			}
		});
		
		desniPanel.add(radioDugmad);
		desniPanel.add(postavi);
		desniPanel.add(nasumicno);
		
		this.add(desniPanel, BorderLayout.EAST);
	}


	public static void main(String[] args) {
		new Igra();
	}

}
