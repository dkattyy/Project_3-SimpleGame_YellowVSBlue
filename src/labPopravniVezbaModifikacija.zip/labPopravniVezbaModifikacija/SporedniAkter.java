package labPopravniVezbaModifikacija;

import java.awt.Color;
import java.awt.Graphics;

public class SporedniAkter extends Akter {

	public SporedniAkter(Teren t, Pozicija p) {
		super(t, p);
		
	}

	@Override
	public void iscrtajAktera(Polje p) {
		Graphics g=p.getGraphics();
		
		g.setColor(Color.black);
		g.drawOval(p.getWidth()/4, p.getWidth()/4, p.getWidth()/2, p.getWidth()/2);
		
		g.setColor(Color.BLUE);
		g.fillOval(p.getWidth()/4, p.getWidth()/4, p.getWidth()/2, p.getWidth()/2);
		
	}

}
