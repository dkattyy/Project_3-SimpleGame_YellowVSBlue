package labPopravniVezbaModifikacija;

public class Pozicija {

	private int vrsta, kolona;

	public Pozicija(int vrsta, int kolona) {
		super();
		this.vrsta = vrsta;
		this.kolona = kolona;
	}

	public int getVrsta() {
		return vrsta;
	}

	public int getKolona() {
		return kolona;
	}
	
	
}
