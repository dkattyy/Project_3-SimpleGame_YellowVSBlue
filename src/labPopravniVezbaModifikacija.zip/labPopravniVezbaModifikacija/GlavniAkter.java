package labPopravniVezbaModifikacija;

import java.awt.Color;
import java.awt.Graphics;

public class GlavniAkter extends Akter{

	public GlavniAkter(Teren t, Pozicija p) {
		super(t, p);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void iscrtajAktera(Polje p) {
		Graphics g=p.getGraphics();
		
		g.setColor(Color.black);
		g.drawOval(p.getWidth()/4, p.getWidth()/4, p.getWidth()/2, p.getWidth()/2);
		
		g.setColor(Color.yellow);
		g.fillOval(p.getWidth()/4, p.getWidth()/4, p.getWidth()/2, p.getWidth()/2);
		
	}

}
